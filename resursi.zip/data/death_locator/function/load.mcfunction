scoreboard objectives add bizcub.deaths deathCount
scoreboard objectives add bizcub.healths health
scoreboard objectives add bizcub.use_recovery_compass trigger
scoreboard objectives add bizcub.dont_use_recovery_compass trigger
scoreboard objectives add bizcub.clear_all_points trigger

execute unless score use bizcub.use_recovery_compass matches 0.. run scoreboard players set use bizcub.use_recovery_compass 0
scoreboard players enable @a bizcub.use_recovery_compass
scoreboard players enable @a bizcub.clear_all_points
