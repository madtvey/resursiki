$summon armor_stand $(x) $(y) $(z) {Tags:[bizcub.death_locator],Invisible:true}

execute as @e[type=armor_stand,tag=bizcub.death_locator] run attribute @s waypoint_transmit_range base set 60000000
execute as @e[type=armor_stand,tag=bizcub.death_locator] run waypoint modify @s style set skull
