kill @e[type=armor_stand,tag=bizcub.death_locator]
scoreboard players set use bizcub.clear_all_points 0
scoreboard players enable @a bizcub.clear_all_points
