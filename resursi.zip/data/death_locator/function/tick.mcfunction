function death_locator:use_recovery_compass

execute if score use bizcub.use_recovery_compass matches 1 if items entity @a container.* recovery_compass as @e[type=armor_stand,tag=bizcub.death_locator] run attribute @s waypoint_transmit_range base set 60000000
execute if score use bizcub.use_recovery_compass matches 1 unless items entity @a container.* recovery_compass as @e[type=armor_stand,tag=bizcub.death_locator] run attribute @s waypoint_transmit_range base set 0
execute if score use bizcub.use_recovery_compass matches 0 as @e[type=armor_stand,tag=bizcub.death_locator] run attribute @s waypoint_transmit_range base set 60000000

execute if score use bizcub.clear_all_points matches 1 run function death_locator:clear_all_points

execute as @a[scores={bizcub.healths=1..}] at @s run kill @n[type=armor_stand,tag=bizcub.death_locator,distance=..2]

execute as @a[scores={bizcub.deaths=1..}] run data modify storage bizcub death_locator.list set from entity @s LastDeathLocation.pos
execute unless entity @a[scores={bizcub.deaths=1..}] run return fail

data modify storage bizcub death_locator.x set from storage bizcub death_locator.list[0]
data modify storage bizcub death_locator.y set from storage bizcub death_locator.list[1]
data modify storage bizcub death_locator.z set from storage bizcub death_locator.list[2]

scoreboard players reset @a bizcub.deaths

function death_locator:add_point with storage bizcub death_locator
