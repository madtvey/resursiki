execute as @a[scores={bizcub.dont_use_recovery_compass=1..}] run scoreboard players set use bizcub.use_recovery_compass 0
execute as @a[scores={bizcub.dont_use_recovery_compass=1..}] run scoreboard players enable @a bizcub.use_recovery_compass
execute as @a[scores={bizcub.dont_use_recovery_compass=1..}] run scoreboard players reset @a bizcub.dont_use_recovery_compass

execute as @a[scores={bizcub.use_recovery_compass=1..}] run scoreboard players set use bizcub.use_recovery_compass 1
execute as @a[scores={bizcub.use_recovery_compass=1..}] run scoreboard players enable @a bizcub.dont_use_recovery_compass
execute as @a[scores={bizcub.use_recovery_compass=1..}] run scoreboard players reset @a bizcub.use_recovery_compass

execute as @a[scores={bizcub.clear_all_points=1..}] run scoreboard players set use bizcub.clear_all_points 1
execute as @a[scores={bizcub.clear_all_points=1..}] run scoreboard players reset @a bizcub.clear_all_points
