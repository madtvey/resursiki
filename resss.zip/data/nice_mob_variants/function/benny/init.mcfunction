schedule function nice_mob_variants:benny/init 1s

execute as @e[type=minecraft:chicken,name=Benny,tag=!is_benny] run function nice_mob_variants:benny/convert_to
execute as @e[type=minecraft:chicken,name=!Benny,tag=is_benny] run function nice_mob_variants:benny/convert_from